function selectFile(){
    uploadMultipleFiles();
}

var fileInput; var serverUrl;
function uploadMultipleFiles(){
    var folderName = window.location.href.split('EVID=')[1];
    serverRelativeUrlToFolder = 'CAP_Attachments/'+folderName;
    createFolders(serverRelativeUrlToFolder );
    fileInput = $('#'+'FileUpload');   
    var fileCount = fileInput[0].files.length;
    serverUrl = _spPageContextInfo.webAbsoluteUrl;
    var filesUploaded = 0;
    var index;
    for(var i = 0; i < fileCount; i++){
            var getFile = getMultipleFileBuffer(i);
            getFile.done(function(arrayBuffer,i){
                var addFile = addMultipleFileToFolder(arrayBuffer,i);
    })
    }
}
function getMultipleFileBuffer(i) {
    debugger;
    var deferred = jQuery.Deferred();
    var reader = new FileReader();
    reader.onloadend = function (e) {
    deferred.resolve(e.target.result,i);
}
reader.onerror = function (e) {
    deferred.reject(e.target.error);
}

reader.readAsArrayBuffer(fileInput[0].files[i]);
return deferred.promise();

}

function addMultipleFileToFolder(arrayBuffer, i) {
var index = i;
var fileName = fileInput[0].files[index].name;
var fileCollectionEndpoint = String.format(
    "{0}/_api/web/getfolderbyserverrelativeurl('{1}')/files" +
    "/add(overwrite=true, url='{2}')",
    serverUrl, serverRelativeUrlToFolder, fileName);

return jQuery.ajax({
    url: fileCollectionEndpoint,
    type: "POST",
    data: arrayBuffer,
    processData: false,
    headers: {
    "accept": "application/json;odata=verbose",
    "X-RequestDigest": jQuery("#__REQUESTDIGEST").val(),
    "content-length": arrayBuffer.byteLength
}
});
}


function createFolders(serverRelativeUrlToFolder) {  
var siteUrl = _spPageContextInfo.webAbsoluteUrl;
var fullUrl = siteUrl + "/_api/web/folders";
jQuery.ajax({
'url' : siteUrl + "/_api/Web/Folders/Add('"+ serverRelativeUrlToFolder + "')",
'type' : 'POST',
'headers' : {
'accept' : 'application/json; odata=verbose',
'content-type' : 'application/json; odata=verbose',
'X-RequestDigest' : $('#__REQUESTDIGEST').val()
},

success: function (data) {

},

error: function (data) {

}

}) }